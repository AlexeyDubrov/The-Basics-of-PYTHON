country = 'Russia'
age = 28
num = 2.46879
my_list = ['Max', 'Leo', 'Alex']
print (country)
print(age)
print(num)
print(my_list)
print(type(country))
print(type(age))
print(type(num))
print(type(my_list))